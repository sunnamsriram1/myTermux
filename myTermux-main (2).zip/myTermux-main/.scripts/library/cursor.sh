#!/usr/bin/env bash

function setCursor() {

  setterm -cursor ${1}

}